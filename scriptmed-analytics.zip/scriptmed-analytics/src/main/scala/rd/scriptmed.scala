package rd


import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.kafka010.ConsumerStrategies._
import org.apache.spark.streaming.kafka010.LocationStrategies._
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.kafka.common.serialization.StringDeserializer

case class Message(val facility:String)

object scriptmed extends Serializable {

    def parseMessage(str: String): Message = {
      Message(str)
    }
    def processMessage(message:ConsumerRecord[String,String]):ConsumerRecord[String,String]={
    message
    }
    def main(args: Array[String]): Unit = {
      val spark = SparkSession.builder
        .appName("scripmed-processing")
        .master("local[*]")
        .getOrCreate()

      val batchDuration = 60
      val bootstrapServers =  "host:port,host:port,host:port"
      val topic = "scriptmed_trascation"  //topics..
      val topicsSet = topic.split(",").toSet
      val topics = topicsSet.toArray
      val consumerGroupID = "test"
      val ssc = new StreamingContext(spark.sparkContext, Seconds(30))

      val kafkaParams = Map[String, Object](
        "bootstrap.servers" -> bootstrapServers,
        "key.deserializer" -> classOf[StringDeserializer],
        "value.deserializer" -> classOf[StringDeserializer],
        "group.id" -> consumerGroupID,
        "auto.offset.reset" -> "earliest",
        "enable.auto.commit" -> (false: java.lang.Boolean)
      )

      val inputDStream = KafkaUtils.createDirectStream[String, String](ssc,PreferConsistent,
        Subscribe[String, String](topics, kafkaParams)
      )
      import spark.implicits._
      val ds = inputDStream.foreachRDD((rdd,batchTime) => {
        val newRDD = rdd.map(message => processMessage(message))
        val data=newRDD.map(f => f.value()).map { x =>
          Message(x.toString)
          /// parsing loigc..
        }.toDF()
        data.show()
      })

      ssc.start()
      ssc.awaitTermination()
      ssc.stop()
    }
  }

